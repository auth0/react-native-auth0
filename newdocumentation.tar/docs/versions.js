"use strict"
export const DOC_VERSIONS = [
	'dev',
	'v5.0',
];
